void main(){

  //0, 1, 2, ..... 9

  //10, 9, 8, ..... 0
 /* for(int no = 10; no >= 0; no--){
    print("$no. Hello World!!");
  }*/

  /*int i = 10;

  while(i>=0){
    print("$i. Hello World!!");
    i--;
  }*/

  int no = 100;


  while(no>5){ ///100, 20,
    print("$no. Hello World!!");
    no = no~/5;
  }


}